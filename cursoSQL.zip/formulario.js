/*
 * Pese a poder evaluar las expresiones de las entradas mediante el atributo 'pattern', 'minlength', 'maxlength' y 'required', se han elaborado
 * las funciones de validaci�n, poder ejecutar las validaciones personalizadas que se estimen oportunas
 * Por ello, se ha indicado el atributo novalidate en el formulario, para evitar los eventos asociados por defecto
 */

//Al cargar el documento lo primero que hace es validar las entradas
document.addEventListener("DOMContentLoaded", function (event) {
    validateAllInputs();
});

function submitForm() {
    //Primero evalua la validez de las entradas de forma redundante por seguridad
    var result = validateAllInputs();
    if (!result) {
        alert("Los campos introducidos no son correctos, corrijalos antes de continuar.")
        event.preventDefault()
        return false;
    } else {
        return true;
    }
}

function validateAllInputs() {
    var result = true;
    //Sentencias if consecutivas para evitar que un resultado true pueda anular uno anterior false
    if (!validateName(document.getElementById("nombre"))) {
        result = false
    }
    if (!validateName(document.getElementById("apellido"))) {
        result = false
    }
    if (!validateEmail(document.getElementById("email"))) {
        result = false;
    }
    return result;
}

function validateName(el) {
    const regex = /^[a-zA-Z ]*$/;
    var errorEl;
    if (el.id == "nombre") {
        errorEl = document.getElementById("nombreErr");
    } else {
        errorEl = document.getElementById("apellidoErr");
    }
    
    const divEl = el.closest('.input-wrapper');
    var result = true;
    if (el.value == null || el.value == "") {
        errorEl.innerHTML = "Rellene este campo";
        result = false;
    }
    if (result) {
        result = regex.test(el.value);
        if (!result) {
            errorEl.innerHTML = "El campo solo puede contener letras mayusculas y minusculas";
        }
    }
   
    if (!result) {
        errorEl.classList.remove("hide");
        errorEl.classList.add("show");
        divEl.classList.remove("valid");
        divEl.classList.add("invalid");
        return false;
    } else {
        errorEl.classList.remove("show");
        errorEl.classList.add("hide");
        divEl.classList.remove("invalid");
        divEl.classList.add("valid");
        errorEl.innerHTML = "";
        return true;
    }
}


function validateEmail(el) {
    var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    const errorEl = document.getElementById("emailErr");
    const divEl = el.closest('.input-wrapper');
    var result = true;
    if (el.value == null || el.value == "") {
        result = false;
        errorEl.innerHTML = "Rellene este campo";
    }
    if (result) {
        result = regex.test(el.value);
        if (!result) {
            //Evalua el motivo por el cual el email no cumple el formato
            regex = /^[a-zA-Z0-9._-]+@/;
            if (!(regex.test(el.value))) {
                errorEl.innerHTML = "No cumple el formato: Debe incluir un simbolo @";
            } else {
                regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]/;
                if (!(regex.test(el.value))) {
                    errorEl.innerHTML = "No cumple el formato: Debe incluir un nombre del dominio, como '.gmail.com'";
                } else {
                    regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]/;
                    if (!(regex.test(el.value))) {
                        errorEl.innerHTML = "No cumple el formato: Debe incluir el sufijo, como '.com' o '.es'";
                    } else {
                        errorEl.innerHTML = "No cumple el formato: El sufijo debe tener entre 2 y 4 caracteres, como '.com' o '.es'";
                    }
                }
            }
        }
    }

    if (!result) {
        errorEl.classList.remove("hide");
        errorEl.classList.add("show");
        divEl.classList.remove("valid");
        divEl.classList.add("invalid");
        return false;
    } else {
        errorEl.classList.remove("show");
        errorEl.classList.add("hide");
        divEl.classList.remove("invalid");
        divEl.classList.add("valid");
        errorEl.innerHTML = "";
        return true;
    }
}
