<?php
	if($_POST){
		$nombre =  $_POST['nombre'];
		$apellido = $_POST['apellido'];
		$email = $_POST['email'];

		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "cursosql";

		$conn = new mysqli($servername, $username, $password, $dbname);
		if($conn->connect_error){
		die("Fallo de conexi�n: " . $conn->connect_error);
		}

		$sqlquery= "SELECT COUNT(1) FROM usuario WHERE email = '$email'";
		if($conn->query($sqlquery) === TRUE){
			$conn->close();
			die("<div style='color:red; border:2px solid red; text-align:center;'><h3>" . 
					"No se ha podido comprobar la existencia de registros coincidentes <small>(" . $sqlquery . "<br>" . $conn->error . ")</small>" .
				"</h3><div>");
		} else {
			if($conn->query($sqlquery)->fetch_row()[0]>0){
				$conn->close();
				die("<div style='color:red; border:2px solid red; text-align:center;'><h3>" . 
						"Ya existe un usuario con el correo facilitado: " . $email . 
					"</h3><div>");
			}
		}


		$sqlquery= "INSERT INTO usuario (nombre, apellido, email) VALUES ('$nombre', '$apellido', '$email')";
		if($conn->query($sqlquery) === TRUE){
			echo "<div style='color:green; border:2px solid green; text-align:center;'><h3>" . 
					"Usuario registrado correctamente!" .
				 "</h3><div>";
		} else {
			die("<div style='color:red; border:2px solid red; text-align:center;'><h3>" . 
					"No se ha podido suscribir el usuario <small>(" . $sqlquery . "<br>" . $conn->error . ")</small>" .
				"</h3><div>");
		}

		$conn->close();
	}
?>

